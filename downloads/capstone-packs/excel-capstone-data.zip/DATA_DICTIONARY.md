# Data dictionary

## Sales.csv
- `Date`: date or categorical value
- `OrderID`: identifier
- `CustomerID`: identifier
- `StoreID`: identifier
- `Region`: date or categorical value
- `Channel`: date or categorical value
- `ProductID`: identifier
- `Product`: date or categorical value
- `Category`: date or categorical value
- `Quantity`: numeric measure
- `UnitPrice`: numeric measure
- `UnitCost`: numeric measure
- `Revenue`: numeric measure
- `Cost`: numeric measure
- `Profit`: numeric measure
## Products.csv
- `ProductID`: identifier
- `Product`: date or categorical value
- `Category`: date or categorical value
- `UnitPrice`: numeric measure
- `UnitCost`: numeric measure
