# Data dictionary

## CustomerSurvey.csv
- `RespondentID`: identifier
- `Region`: date or categorical value
- `Channel`: date or categorical value
- `SatisfactionScore`: numeric measure
- `TransactionTotal`: numeric measure
