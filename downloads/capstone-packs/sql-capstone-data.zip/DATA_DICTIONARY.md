# Data dictionary

## Customers.csv
- `CustomerID`: identifier
- `Region`: date or categorical value
- `Channel`: date or categorical value
## Orders.csv
- `OrderID`: identifier
- `CustomerID`: identifier
- `OrderDate`: date or categorical value
## OrderLines.csv
- `OrderID`: identifier
- `ProductID`: identifier
- `Quantity`: numeric measure
- `UnitPrice`: numeric measure
## Products.csv
- `ProductID`: identifier
- `Product`: date or categorical value
- `Category`: date or categorical value
- `UnitPrice`: numeric measure
- `UnitCost`: numeric measure
