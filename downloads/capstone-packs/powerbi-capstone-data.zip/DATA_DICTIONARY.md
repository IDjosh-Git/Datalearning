# Data dictionary

## Sales.csv
- `Date`: date or categorical value
- `OrderID`: identifier
- `CustomerID`: identifier
- `StoreID`: identifier
- `ProductID`: identifier
- `Quantity`: numeric measure
- `UnitPrice`: numeric measure
- `UnitCost`: numeric measure
## Products.csv
- `ProductID`: identifier
- `Product`: date or categorical value
- `Category`: date or categorical value
- `UnitPrice`: numeric measure
- `UnitCost`: numeric measure
## Customers.csv
- `CustomerID`: identifier
- `Region`: date or categorical value
- `Channel`: date or categorical value
## Stores.csv
- `StoreID`: identifier
- `Region`: date or categorical value
## Calendar.csv
- `Date`: date or categorical value
- `Year`: numeric measure
- `Month`: numeric measure
